"""
Phase 5 — Scheduled Health Check Daemon
Runs periodic health checks using the Phase 4 agent tools,
detects anomalies, and sends alerts via email or webhook.

Usage:
  python3 scheduler.py                  # Run daemon (default: every 30 min)
  python3 scheduler.py --once           # Run one check and exit
  python3 scheduler.py --interval 15    # Custom interval in minutes
"""
import time
import json
import os
import sys
import argparse
import logging
from datetime import datetime, timedelta
from pathlib import Path

# Add phase4-agents to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'phase4-agents'))

import pg_tool
import loki_tool
import system_tool
import pgtune_tool

# ── Configuration ─────────────────────────────────────────
CONFIG = {
    "check_interval_minutes": 30,
    "report_dir": os.path.expanduser("~/ai-infra-reports"),
    "alert_webhook_url": None,           # Set to Slack/Teams webhook URL
    "alert_email": None,                  # Set to email address
    "smtp_host": "localhost",
    "smtp_port": 25,
    "thresholds": {
        "replication_lag_bytes": 10_000_000,    # 10MB
        "cpu_percent": 85.0,
        "disk_percent": 85.0,
        "active_connections_percent": 80,       # % of max_connections
        "lock_wait_seconds": 30,
        "error_count_per_hour": 10,
    }
}

# ── Logging Setup ─────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(os.path.expanduser("~/ai-infra-reports/scheduler.log"))
    ]
)
log = logging.getLogger("scheduler")


# ── Health Check Engine ───────────────────────────────────
class HealthChecker:
    """Runs all health checks and collects results."""

    def __init__(self):
        self.results = {}
        self.alerts = []
        self.timestamp = datetime.now()

    def check_pg_replication(self):
        """Check PostgreSQL replication status and lag."""
        log.info("Checking PostgreSQL replication...")
        try:
            result = pg_tool.get_replication_status()
            self.results["pg_replication"] = result

            # Parse for replication lag
            if "sent_lsn" in result and "replay_lsn" in result:
                # If lag is reported, check threshold
                if "lag" in result.lower() or "behind" in result.lower():
                    self.alerts.append({
                        "severity": "HIGH",
                        "component": "PostgreSQL Replication",
                        "message": f"Replication lag detected",
                        "detail": result[:500]
                    })
            if "error" in result.lower() or "could not connect" in result.lower():
                self.alerts.append({
                    "severity": "CRITICAL",
                    "component": "PostgreSQL Replication",
                    "message": "Cannot connect to PostgreSQL to check replication",
                    "detail": result[:500]
                })
        except Exception as e:
            self.results["pg_replication"] = f"ERROR: {e}"
            self.alerts.append({
                "severity": "CRITICAL",
                "component": "PostgreSQL Replication",
                "message": f"Health check failed: {e}",
                "detail": str(e)
            })

    def check_pg_connections(self):
        """Check active connections against max_connections."""
        log.info("Checking PostgreSQL connections...")
        try:
            result = pg_tool.get_active_connections()
            self.results["pg_connections"] = result
        except Exception as e:
            self.results["pg_connections"] = f"ERROR: {e}"

    def check_pg_locks(self):
        """Check for blocking locks."""
        log.info("Checking PostgreSQL locks...")
        try:
            result = pg_tool.get_locks()
            self.results["pg_locks"] = result

            if "blocked" in result.lower() or "waiting" in result.lower():
                self.alerts.append({
                    "severity": "HIGH",
                    "component": "PostgreSQL Locks",
                    "message": "Blocking locks detected",
                    "detail": result[:500]
                })
        except Exception as e:
            self.results["pg_locks"] = f"ERROR: {e}"

    def check_pg_errors(self):
        """Check for recent PostgreSQL errors in Loki."""
        log.info("Checking PostgreSQL error logs...")
        try:
            result = loki_tool.fetch_errors("postgresql", minutes=60)
            self.results["pg_errors"] = result

            if "found" in result.lower() and "error" in result.lower() and "no errors" not in result.lower():
                self.alerts.append({
                    "severity": "MEDIUM",
                    "component": "PostgreSQL Logs",
                    "message": "Errors detected in PostgreSQL logs",
                    "detail": result[:500]
                })
        except Exception as e:
            self.results["pg_errors"] = f"ERROR: {e}"

    def check_system_resources(self):
        """Check CPU, memory, disk on all servers."""
        log.info("Checking system resources...")
        try:
            result = system_tool.get_all_servers_report()
            self.results["system_resources"] = result

            # Parse for high disk usage
            for line in result.split("\n"):
                if "Use%:" in line:
                    try:
                        pct = int(line.split("Use%:")[1].strip().rstrip("%"))
                        if pct > CONFIG["thresholds"]["disk_percent"]:
                            self.alerts.append({
                                "severity": "HIGH",
                                "component": "Disk Space",
                                "message": f"Disk usage at {pct}%",
                                "detail": line.strip()
                            })
                    except (ValueError, IndexError):
                        pass
        except Exception as e:
            self.results["system_resources"] = f"ERROR: {e}"

    def check_security(self):
        """Run security audit."""
        log.info("Running security audit...")
        try:
            result = pgtune_tool.get_security_audit("pg-node1")
            self.results["security_audit"] = result

            if "CRITICAL" in result:
                self.alerts.append({
                    "severity": "MEDIUM",
                    "component": "Security Audit",
                    "message": "Critical security findings detected",
                    "detail": result[:500]
                })
        except Exception as e:
            self.results["security_audit"] = f"ERROR: {e}"

    def run_all_checks(self):
        """Run complete health check suite."""
        log.info(f"{'='*60}")
        log.info(f"Starting scheduled health check at {self.timestamp}")
        log.info(f"{'='*60}")

        self.check_pg_replication()
        self.check_pg_connections()
        self.check_pg_locks()
        self.check_pg_errors()
        self.check_system_resources()
        self.check_security()

        log.info(f"Health check complete. Alerts: {len(self.alerts)}")
        return self.generate_report()

    def generate_report(self) -> dict:
        """Generate structured health report."""
        report = {
            "timestamp": self.timestamp.isoformat(),
            "status": "CRITICAL" if any(a["severity"] == "CRITICAL" for a in self.alerts)
                      else "WARNING" if self.alerts
                      else "HEALTHY",
            "alert_count": len(self.alerts),
            "alerts": self.alerts,
            "checks": {k: v[:200] + "..." if len(v) > 200 else v
                       for k, v in self.results.items()},
        }
        return report


# ── Report Storage ────────────────────────────────────────
def save_report(report: dict):
    """Save report to disk as JSON."""
    report_dir = Path(CONFIG["report_dir"])
    report_dir.mkdir(parents=True, exist_ok=True)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    filepath = report_dir / f"health_{ts}.json"
    with open(filepath, "w") as f:
        json.dump(report, f, indent=2, default=str)

    log.info(f"Report saved: {filepath}")

    # Keep only last 7 days of reports
    cutoff = datetime.now() - timedelta(days=7)
    for old in sorted(report_dir.glob("health_*.json")):
        try:
            file_date = datetime.strptime(old.stem.split("_", 1)[1], "%Y%m%d_%H%M%S")
            if file_date < cutoff:
                old.unlink()
                log.info(f"Cleaned up old report: {old.name}")
        except (ValueError, IndexError):
            pass

    return filepath


# ── Alerting ──────────────────────────────────────────────
def send_alerts(report: dict):
    """Send alerts via configured channels."""
    if report["status"] == "HEALTHY":
        return

    alert_text = format_alert_text(report)

    # Webhook (Slack/Teams)
    if CONFIG["alert_webhook_url"]:
        send_webhook_alert(alert_text)

    # Email
    if CONFIG["alert_email"]:
        send_email_alert(alert_text, report)

    # Always log alerts
    for alert in report["alerts"]:
        log.warning(f"ALERT [{alert['severity']}] {alert['component']}: {alert['message']}")


def format_alert_text(report: dict) -> str:
    """Format alerts for human reading."""
    lines = []
    lines.append(f"🚨 AI Infra Monitor — {report['status']}")
    lines.append(f"Time: {report['timestamp']}")
    lines.append(f"Alerts: {report['alert_count']}")
    lines.append("")

    for a in report["alerts"]:
        icon = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡"}.get(a["severity"], "🔵")
        lines.append(f"{icon} [{a['severity']}] {a['component']}")
        lines.append(f"   {a['message']}")
        if a.get("detail"):
            lines.append(f"   Detail: {a['detail'][:200]}")
        lines.append("")

    return "\n".join(lines)


def send_webhook_alert(text: str):
    """Send alert to Slack/Teams webhook."""
    import requests
    try:
        payload = {"text": text}
        resp = requests.post(CONFIG["alert_webhook_url"], json=payload, timeout=10)
        if resp.status_code == 200:
            log.info("Webhook alert sent successfully")
        else:
            log.error(f"Webhook alert failed: {resp.status_code}")
    except Exception as e:
        log.error(f"Webhook alert error: {e}")


def send_email_alert(text: str, report: dict):
    """Send alert via email."""
    import smtplib
    from email.mime.text import MIMEText
    try:
        msg = MIMEText(text)
        msg["Subject"] = f"[AI Infra] {report['status']} — {report['alert_count']} alerts"
        msg["From"] = "ai-infra@localhost"
        msg["To"] = CONFIG["alert_email"]

        with smtplib.SMTP(CONFIG["smtp_host"], CONFIG["smtp_port"]) as smtp:
            smtp.send_message(msg)
        log.info(f"Email alert sent to {CONFIG['alert_email']}")
    except Exception as e:
        log.error(f"Email alert error: {e}")


# ── AI Summary (uses Mistral) ─────────────────────────────
def generate_ai_summary(report: dict) -> str:
    """Use Mistral to generate a plain-English health summary."""
    try:
        from langchain_ollama import OllamaLLM
        from langchain_core.prompts import PromptTemplate

        llm = OllamaLLM(
            model="mistral:7b-instruct-q4_K_M",
            base_url="http://localhost:11434",
            temperature=0.1
        )

        prompt = PromptTemplate(
            template="""You are a Senior DBA reviewing an automated health check report.

Health Check Report:
Status: {status}
Alerts: {alert_count}

Alert Details:
{alerts}

Check Results Summary:
{checks}

Write a concise daily health summary (5-8 sentences) covering:
1. Overall cluster health status
2. Any critical issues that need immediate attention
3. Any warnings or trends to watch
4. One recommendation for improvement

Keep it professional and actionable. No boilerplate.""",
            input_variables=["status", "alert_count", "alerts", "checks"]
        )

        chain = prompt | llm
        summary = chain.invoke({
            "status": report["status"],
            "alert_count": report["alert_count"],
            "alerts": json.dumps(report["alerts"], indent=2, default=str),
            "checks": json.dumps(report["checks"], indent=2, default=str),
        })

        return summary

    except Exception as e:
        return f"AI summary unavailable: {e}"


# ── Daily Digest ──────────────────────────────────────────
def generate_daily_digest():
    """Aggregate last 24h of reports into a daily digest."""
    report_dir = Path(CONFIG["report_dir"])
    cutoff = datetime.now() - timedelta(hours=24)

    reports = []
    for f in sorted(report_dir.glob("health_*.json")):
        try:
            file_date = datetime.strptime(f.stem.split("_", 1)[1], "%Y%m%d_%H%M%S")
            if file_date >= cutoff:
                with open(f) as fh:
                    reports.append(json.load(fh))
        except (ValueError, IndexError, json.JSONDecodeError):
            pass

    if not reports:
        return "No health checks found in the last 24 hours."

    total_alerts = sum(r["alert_count"] for r in reports)
    statuses = [r["status"] for r in reports]
    critical_count = statuses.count("CRITICAL")
    warning_count = statuses.count("WARNING")
    healthy_count = statuses.count("HEALTHY")

    # Collect all unique alerts
    seen = set()
    unique_alerts = []
    for r in reports:
        for a in r.get("alerts", []):
            key = f"{a['component']}:{a['message']}"
            if key not in seen:
                seen.add(key)
                unique_alerts.append(a)

    digest = []
    digest.append(f"{'='*60}")
    digest.append(f"DAILY HEALTH DIGEST — {datetime.now().strftime('%Y-%m-%d')}")
    digest.append(f"{'='*60}")
    digest.append(f"Checks run:      {len(reports)}")
    digest.append(f"  Healthy:       {healthy_count}")
    digest.append(f"  Warning:       {warning_count}")
    digest.append(f"  Critical:      {critical_count}")
    digest.append(f"Total alerts:    {total_alerts}")
    digest.append(f"Unique issues:   {len(unique_alerts)}")

    if unique_alerts:
        digest.append(f"\n--- Unique Issues ---")
        for a in unique_alerts:
            icon = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡"}.get(a["severity"], "🔵")
            digest.append(f"  {icon} [{a['severity']}] {a['component']}: {a['message']}")

    digest.append(f"{'='*60}")
    return "\n".join(digest)


# ── Main Loop ─────────────────────────────────────────────
def run_single_check():
    """Run one health check cycle."""
    checker = HealthChecker()
    report = checker.run_all_checks()

    # Save report
    filepath = save_report(report)

    # Send alerts if needed
    send_alerts(report)

    # Generate AI summary
    log.info("Generating AI summary...")
    summary = generate_ai_summary(report)
    report["ai_summary"] = summary

    # Update saved report with summary
    with open(filepath, "w") as f:
        json.dump(report, f, indent=2, default=str)

    # Print summary
    print(f"\n{'='*60}")
    print(f"HEALTH CHECK RESULT: {report['status']}")
    print(f"{'='*60}")
    print(f"Alerts: {report['alert_count']}")
    for a in report["alerts"]:
        print(f"  [{a['severity']}] {a['component']}: {a['message']}")
    print(f"\nAI Summary:\n{summary}")
    print(f"\nFull report: {filepath}")
    print(f"{'='*60}")

    return report


def main():
    parser = argparse.ArgumentParser(description="AI Infra Scheduled Health Checker")
    parser.add_argument("--once", action="store_true", help="Run once and exit")
    parser.add_argument("--interval", type=int, default=30, help="Check interval in minutes")
    parser.add_argument("--digest", action="store_true", help="Generate daily digest and exit")
    parser.add_argument("--webhook", type=str, help="Slack/Teams webhook URL for alerts")
    parser.add_argument("--email", type=str, help="Email address for alerts")
    args = parser.parse_args()

    # Apply config overrides
    CONFIG["check_interval_minutes"] = args.interval
    if args.webhook:
        CONFIG["alert_webhook_url"] = args.webhook
    if args.email:
        CONFIG["alert_email"] = args.email

    # Ensure report directory exists
    Path(CONFIG["report_dir"]).mkdir(parents=True, exist_ok=True)

    if args.digest:
        print(generate_daily_digest())
        return

    if args.once:
        run_single_check()
        return

    # Daemon mode
    log.info(f"Starting health check daemon (interval: {args.interval} min)")
    log.info(f"Reports saved to: {CONFIG['report_dir']}")
    if CONFIG["alert_webhook_url"]:
        log.info(f"Webhook alerts enabled")
    if CONFIG["alert_email"]:
        log.info(f"Email alerts to: {CONFIG['alert_email']}")

    while True:
        try:
            run_single_check()
        except Exception as e:
            log.error(f"Health check cycle failed: {e}")

        next_run = datetime.now() + timedelta(minutes=args.interval)
        log.info(f"Next check at {next_run.strftime('%H:%M:%S')}")
        time.sleep(args.interval * 60)


if __name__ == "__main__":
    main()
