"""
Phase 5 — FastAPI Web Interface for AI Infrastructure Agent
Provides REST API and web UI for querying the agent, viewing reports,
and managing scheduled health checks.

Usage:
  uvicorn api:app --host 0.0.0.0 --port 8080 --reload
"""
import os
import sys
import json
import glob
from datetime import datetime
from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

# Add phase4-agents to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'phase4-agents'))

import pg_tool
import mongo_tool
import loki_tool
import system_tool
import pgtune_tool
from infra_context import get_live_context

# Lazy-load LLM to avoid startup delay
_llm = None
def get_llm():
    global _llm
    if _llm is None:
        from langchain_ollama import OllamaLLM
        _llm = OllamaLLM(
            model="mistral:7b-instruct-q4_K_M",
            base_url="http://localhost:11434",
            temperature=0.1
        )
    return _llm

REPORT_DIR = os.path.expanduser("~/ai-infra-reports")

# ── FastAPI App ───────────────────────────────────────────
app = FastAPI(
    title="AI Infra Monitor",
    description="AI-powered infrastructure monitoring for PostgreSQL, MongoDB & Kubernetes",
    version="5.0.0"
)

# ── Models ────────────────────────────────────────────────
class QueryRequest(BaseModel):
    question: str

class QueryResponse(BaseModel):
    question: str
    answer: str
    tools_used: list
    timestamp: str

# ── Tool Registry (mirrors agent.py) ─────────────────────
TOOLS = {
    "pg_replication":  ("Check PostgreSQL replication status and lag",         pg_tool.get_replication_status),
    "pg_connections":  ("Get active PostgreSQL connections and queries",        pg_tool.get_active_connections),
    "pg_slow_queries": ("Get slow queries from pg_stat_statements",            pg_tool.get_slow_queries),
    "pg_db_sizes":     ("Get PostgreSQL database sizes",                       pg_tool.get_database_sizes),
    "pg_locks":        ("Check for PostgreSQL locks and blocking queries",     pg_tool.get_locks),
    "mongo_status":    ("Get MongoDB server status, connections and memory",   mongo_tool.get_server_status),
    "mongo_databases": ("List MongoDB databases with sizes",                   mongo_tool.get_databases),
    "mongo_slow_ops":  ("Check for slow MongoDB operations",                   mongo_tool.get_slow_operations),
    "mongo_replica":   ("Get MongoDB replica set status",                      mongo_tool.get_replica_status),
    "pg_logs":         ("Fetch recent PostgreSQL logs from Loki",              lambda: loki_tool.fetch_recent_logs("postgresql", minutes=30, limit=20)),
    "mongo_logs":      ("Fetch recent MongoDB logs from Loki",                 lambda: loki_tool.fetch_recent_logs("mongodb", minutes=30, limit=20)),
    "pg_errors":       ("Check PostgreSQL logs for errors and warnings",       lambda: loki_tool.fetch_errors("postgresql", minutes=60)),
    "mongo_errors":    ("Check MongoDB logs for errors and warnings",          lambda: loki_tool.fetch_errors("mongodb", minutes=60)),
    "all_servers_report": ("Get CPU, memory and disk report for ALL servers",  system_tool.get_all_servers_report),
    "pg_tuning":       ("Get PGTune-style tuning recommendations",             pgtune_tool.get_tuning_recommendations),
    "pg_security":     ("Run a security hardening audit on PostgreSQL",        pgtune_tool.get_security_audit),
    "pg_full_health":  ("Get combined tuning + security audit report",         pgtune_tool.get_full_health_report),
}


# ── AI Query Endpoint ─────────────────────────────────────
@app.post("/api/query", response_model=QueryResponse)
async def query_agent(req: QueryRequest):
    """Ask the AI agent a question about your infrastructure."""
    import re
    from langchain_core.prompts import PromptTemplate
    from langchain_core.output_parsers import StrOutputParser

    llm = get_llm()

    # Get live context
    context = get_live_context()

    # Tool selection
    tools_desc = "\n".join([f"- {name}: {desc}" for name, (desc, _) in TOOLS.items()])

    plan_prompt = PromptTemplate(
        template="""You are an expert DBA. Select the most relevant tools to answer this question.

Infrastructure Status:
{context}

Available tools:
{tools}

Question: {question}

Reply with ONLY a comma-separated list of tool names.""",
        input_variables=["context", "tools", "question"]
    )

    plan_chain = plan_prompt | llm | StrOutputParser()
    tool_response = plan_chain.invoke({
        "context": context, "tools": tools_desc, "question": req.question
    })

    selected = [t.strip() for t in re.split(r"[,\n]", tool_response) if t.strip() in TOOLS]
    if not selected:
        selected = ["pg_replication"]

    # Run tools
    data_parts = []
    for tool_name in selected:
        _, fn = TOOLS[tool_name]
        result = fn()
        data_parts.append(f"=== {tool_name} ===\n{result}")

    all_data = "\n\n".join(data_parts)

    # Generate answer
    answer_prompt = PromptTemplate(
        template="""You are an expert DBA.

Infrastructure Status:
{context}

Live data:
{data}

Question: {question}

Provide a clear, detailed answer based on the live data above:""",
        input_variables=["context", "data", "question"]
    )

    answer_chain = answer_prompt | llm | StrOutputParser()
    answer = answer_chain.invoke({
        "context": context, "data": all_data, "question": req.question
    })

    return QueryResponse(
        question=req.question,
        answer=answer,
        tools_used=selected,
        timestamp=datetime.now().isoformat()
    )


# ── Direct Tool Endpoints ─────────────────────────────────
@app.get("/api/tools")
async def list_tools():
    """List all available tools."""
    return {name: desc for name, (desc, _) in TOOLS.items()}

@app.get("/api/tools/{tool_name}")
async def run_tool(tool_name: str):
    """Run a specific tool directly."""
    if tool_name not in TOOLS:
        return JSONResponse(status_code=404, content={"error": f"Tool '{tool_name}' not found"})
    _, fn = TOOLS[tool_name]
    result = fn()
    return {"tool": tool_name, "result": result, "timestamp": datetime.now().isoformat()}


# ── Reports Endpoints ─────────────────────────────────────
@app.get("/api/reports")
async def list_reports(limit: int = 20):
    """List recent health check reports."""
    report_dir = Path(REPORT_DIR)
    if not report_dir.exists():
        return {"reports": []}

    files = sorted(report_dir.glob("health_*.json"), reverse=True)[:limit]
    reports = []
    for f in files:
        try:
            with open(f) as fh:
                data = json.load(fh)
                reports.append({
                    "filename": f.name,
                    "timestamp": data.get("timestamp"),
                    "status": data.get("status"),
                    "alert_count": data.get("alert_count"),
                })
        except (json.JSONDecodeError, KeyError):
            pass

    return {"reports": reports}


@app.get("/api/reports/{filename}")
async def get_report(filename: str):
    """Get a specific health check report."""
    filepath = Path(REPORT_DIR) / filename
    if not filepath.exists():
        return JSONResponse(status_code=404, content={"error": "Report not found"})
    with open(filepath) as f:
        return json.load(f)


# ── Dashboard Endpoint ────────────────────────────────────
@app.get("/api/status")
async def get_status():
    """Quick infrastructure status check."""
    status = {"timestamp": datetime.now().isoformat(), "services": {}}

    # Check Ollama
    import requests
    try:
        r = requests.get("http://localhost:11434", timeout=3)
        status["services"]["ollama"] = "up"
    except:
        status["services"]["ollama"] = "down"

    # Check Loki
    try:
        r = requests.get("http://localhost:3100/ready", timeout=3)
        status["services"]["loki"] = "up" if "ready" in r.text else "down"
    except:
        status["services"]["loki"] = "down"

    # Check Grafana
    try:
        r = requests.get("http://localhost:3001/api/health", timeout=3)
        status["services"]["grafana"] = "up" if r.status_code == 200 else "down"
    except:
        status["services"]["grafana"] = "down"

    # Check ChromaDB
    try:
        r = requests.get("http://localhost:8000/api/v2/heartbeat", timeout=3)
        status["services"]["chromadb"] = "up" if r.status_code == 200 else "down"
    except:
        status["services"]["chromadb"] = "down"

    return status


# ── Web UI ────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
async def web_ui():
    """Serve the web dashboard."""
    return """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>AI Infra Monitor</title>
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body { font-family: 'Segoe UI',system-ui,sans-serif; background:#0f1117; color:#e1e4e8; }
  .header { background:linear-gradient(135deg,#1a1f35,#0d1117); padding:24px 32px; border-bottom:1px solid #21262d; }
  .header h1 { font-size:24px; color:#58a6ff; }
  .header p { color:#8b949e; margin-top:4px; }
  .container { max-width:960px; margin:0 auto; padding:24px; }
  .status-bar { display:flex; gap:12px; margin-bottom:24px; flex-wrap:wrap; }
  .status-badge { padding:8px 16px; border-radius:8px; font-size:13px; background:#161b22; border:1px solid #21262d; }
  .status-badge.up { border-color:#238636; color:#3fb950; }
  .status-badge.down { border-color:#da3633; color:#f85149; }
  .query-box { background:#161b22; border:1px solid #21262d; border-radius:12px; padding:24px; margin-bottom:24px; }
  .query-box h2 { font-size:16px; color:#58a6ff; margin-bottom:12px; }
  .query-input { display:flex; gap:8px; }
  .query-input input { flex:1; padding:12px 16px; background:#0d1117; border:1px solid #30363d; border-radius:8px; color:#e1e4e8; font-size:15px; outline:none; }
  .query-input input:focus { border-color:#58a6ff; }
  .query-input button { padding:12px 24px; background:#238636; color:white; border:none; border-radius:8px; cursor:pointer; font-size:14px; font-weight:600; }
  .query-input button:hover { background:#2ea043; }
  .query-input button:disabled { background:#21262d; color:#484f58; cursor:wait; }
  .answer-box { background:#161b22; border:1px solid #21262d; border-radius:12px; padding:24px; margin-bottom:24px; display:none; }
  .answer-box h3 { color:#58a6ff; font-size:14px; margin-bottom:8px; }
  .answer-box pre { white-space:pre-wrap; word-wrap:break-word; font-family:'Cascadia Code','Fira Code',monospace; font-size:13px; line-height:1.6; color:#c9d1d9; }
  .tools-used { margin-top:12px; display:flex; gap:6px; flex-wrap:wrap; }
  .tool-tag { padding:4px 10px; background:#0d1117; border:1px solid #30363d; border-radius:4px; font-size:11px; color:#8b949e; }
  .reports { background:#161b22; border:1px solid #21262d; border-radius:12px; padding:24px; }
  .reports h2 { font-size:16px; color:#58a6ff; margin-bottom:12px; }
  .report-row { padding:10px 0; border-bottom:1px solid #21262d; display:flex; justify-content:space-between; align-items:center; }
  .report-status { padding:4px 8px; border-radius:4px; font-size:11px; font-weight:600; }
  .report-status.HEALTHY { background:#0d2818; color:#3fb950; }
  .report-status.WARNING { background:#2d1b00; color:#d29922; }
  .report-status.CRITICAL { background:#2d0000; color:#f85149; }
  .spinner { display:none; border:3px solid #21262d; border-top:3px solid #58a6ff; border-radius:50%; width:20px; height:20px; animation:spin 1s linear infinite; }
  @keyframes spin { to { transform:rotate(360deg); } }
  .examples { margin-top:12px; display:flex; gap:8px; flex-wrap:wrap; }
  .example-btn { padding:6px 12px; background:#0d1117; border:1px solid #30363d; border-radius:6px; color:#8b949e; font-size:12px; cursor:pointer; }
  .example-btn:hover { border-color:#58a6ff; color:#58a6ff; }
</style>
</head>
<body>
<div class="header">
  <h1>🤖 AI Infra Monitor</h1>
  <p>AI-powered database observability — PostgreSQL · MongoDB · Kubernetes</p>
</div>
<div class="container">
  <div class="status-bar" id="statusBar">Loading services...</div>

  <div class="query-box">
    <h2>Ask Your Infrastructure</h2>
    <div class="query-input">
      <input type="text" id="queryInput" placeholder="e.g., Are there any errors in PostgreSQL?" onkeydown="if(event.key==='Enter')askQuery()">
      <button id="askBtn" onclick="askQuery()">Ask</button>
      <div class="spinner" id="spinner"></div>
    </div>
    <div class="examples">
      <span class="example-btn" onclick="setQuery('What is the replication status of PostgreSQL?')">Replication status</span>
      <span class="example-btn" onclick="setQuery('Are there any errors in my databases?')">Check errors</span>
      <span class="example-btn" onclick="setQuery('Give me PGTune recommendations')">PGTune</span>
      <span class="example-btn" onclick="setQuery('Run a security hardening audit')">Security audit</span>
      <span class="example-btn" onclick="setQuery('Get CPU and memory report for all servers')">System resources</span>
    </div>
  </div>

  <div class="answer-box" id="answerBox">
    <h3>🤖 Answer</h3>
    <pre id="answerText"></pre>
    <div class="tools-used" id="toolsUsed"></div>
  </div>

  <div class="reports">
    <h2>Recent Health Reports</h2>
    <div id="reportsList">Loading...</div>
  </div>
</div>

<script>
async function loadStatus() {
  try {
    const r = await fetch('/api/status');
    const d = await r.json();
    const bar = document.getElementById('statusBar');
    bar.innerHTML = '';
    for (const [svc, st] of Object.entries(d.services)) {
      bar.innerHTML += `<div class="status-badge ${st}">${svc}: ${st === 'up' ? '✅' : '❌'} ${st}</div>`;
    }
  } catch(e) { document.getElementById('statusBar').textContent = 'Error loading status'; }
}

async function loadReports() {
  try {
    const r = await fetch('/api/reports?limit=10');
    const d = await r.json();
    const el = document.getElementById('reportsList');
    if (!d.reports.length) { el.innerHTML = '<p style="color:#8b949e">No reports yet. Run the scheduler to generate health reports.</p>'; return; }
    el.innerHTML = d.reports.map(r => `
      <div class="report-row">
        <span>${new Date(r.timestamp).toLocaleString()}</span>
        <span class="report-status ${r.status}">${r.status} (${r.alert_count} alerts)</span>
      </div>`).join('');
  } catch(e) { document.getElementById('reportsList').textContent = 'Error loading reports'; }
}

function setQuery(q) { document.getElementById('queryInput').value = q; }

async function askQuery() {
  const q = document.getElementById('queryInput').value.trim();
  if (!q) return;

  document.getElementById('askBtn').disabled = true;
  document.getElementById('spinner').style.display = 'inline-block';
  document.getElementById('answerBox').style.display = 'block';
  document.getElementById('answerText').textContent = 'Thinking...';
  document.getElementById('toolsUsed').innerHTML = '';

  try {
    const r = await fetch('/api/query', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({question: q})
    });
    const d = await r.json();
    document.getElementById('answerText').textContent = d.answer;
    document.getElementById('toolsUsed').innerHTML = d.tools_used.map(t => `<span class="tool-tag">${t}</span>`).join('');
  } catch(e) {
    document.getElementById('answerText').textContent = 'Error: ' + e.message;
  }

  document.getElementById('askBtn').disabled = false;
  document.getElementById('spinner').style.display = 'none';
}

loadStatus();
loadReports();
setInterval(loadStatus, 30000);
</script>
</body>
</html>"""

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)
