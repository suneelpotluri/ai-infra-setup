# Phase 5 — Automation, Scheduling & Web Interface

This phase adds three capabilities on top of the Phase 4 agent:

## Components

### 1. Scheduled Health Checks (`scheduler.py`)
Runs periodic health checks using all Phase 4 tools, detects anomalies,
saves reports, and sends alerts.

```bash
# Run once
python3 scheduler.py --once

# Run as daemon (every 30 minutes)
python3 scheduler.py --interval 30

# Run with Slack alerts
python3 scheduler.py --webhook https://hooks.slack.com/services/YOUR/WEBHOOK

# Generate daily digest
python3 scheduler.py --digest
```

### 2. FastAPI Web Interface (`api.py`)
A web dashboard and REST API for querying the agent from a browser.

```bash
# Install dependencies
pip install -r requirements.txt

# Start the web server
uvicorn api:app --host 0.0.0.0 --port 8080 --reload

# Or directly
python3 api.py
```

Then open: `http://<WSL2_IP>:8080`

#### API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Web dashboard |
| `/api/query` | POST | Ask the AI agent a question |
| `/api/tools` | GET | List available tools |
| `/api/tools/{name}` | GET | Run a specific tool |
| `/api/status` | GET | Service health status |
| `/api/reports` | GET | List health check reports |
| `/api/reports/{file}` | GET | Get a specific report |

#### Query API Example
```bash
curl -X POST http://localhost:8080/api/query \
  -H "Content-Type: application/json" \
  -d '{"question": "Are there any errors in PostgreSQL?"}'
```

### 3. Systemd Service & Cron

#### Option A: Systemd service (recommended for daemon mode)
```bash
sudo cp ai-infra-scheduler.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable ai-infra-scheduler
sudo systemctl start ai-infra-scheduler
```

#### Option B: Cron (for periodic single checks)
```bash
# Add to crontab
crontab -e

# Run health check every 30 minutes
*/30 * * * * cd /home/sunilp/ai-infra-setup && /home/sunilp/ai-infra-setup/phase3-rag/venv/bin/python3 phase5-automation/scheduler.py --once >> ~/ai-infra-reports/cron.log 2>&1

# Daily digest at 8 AM
0 8 * * * cd /home/sunilp/ai-infra-setup && /home/sunilp/ai-infra-setup/phase3-rag/venv/bin/python3 phase5-automation/scheduler.py --digest >> ~/ai-infra-reports/daily_digest.log 2>&1
```

## Architecture

```
┌─────────────────────────────────────────────┐
│              Phase 5 Layer                   │
│                                              │
│  ┌──────────────┐    ┌──────────────────┐   │
│  │ scheduler.py  │    │    api.py         │   │
│  │ (cron/daemon) │    │  (FastAPI :8080)  │   │
│  └──────┬───────┘    └────────┬─────────┘   │
│         │                     │              │
│         └──────────┬──────────┘              │
│                    │                         │
│         ┌──────────▼──────────┐              │
│         │  Phase 4 Agent Tools │              │
│         │  pg_tool, mongo_tool │              │
│         │  loki_tool, pgtune   │              │
│         │  system_tool         │              │
│         └──────────┬──────────┘              │
│                    │                         │
│    ┌───────────────┼───────────────┐        │
│    ▼               ▼               ▼        │
│  PostgreSQL     MongoDB         Loki        │
│  (live SQL)     (live queries)  (logs)      │
└─────────────────────────────────────────────┘
```

## Reports

Health check reports are saved to `~/ai-infra-reports/` as JSON files.
Each report includes:
- Timestamp and overall status (HEALTHY/WARNING/CRITICAL)
- Individual check results
- Alert details with severity
- AI-generated summary (via Mistral)

Reports are automatically cleaned up after 7 days.
